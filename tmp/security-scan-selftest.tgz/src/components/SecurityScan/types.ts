/**
 * 安全扫描 / API 资产 —— 类型定义
 *
 * 用户侧（监控 → 安全扫描）：CP 开启后，平台在应用部署时解析镜像，列出各应用的 API（入参、作用），CP 确认作用。
 * 管理后台（平台游戏详情 → API 资产）：只读查看每个 API 的鉴权、暴露、风险等级与命中原因，用于封禁决策。
 */

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE'

/** 鉴权类型（一个接口可能叠加多种） */
export type AuthType =
  | 'none'
  | 'static_token'
  | 'basic'
  | 'ip_whitelist'
  | 'signature'
  | 'jwt'
  | 'session'
  | 'platform_token'
  | 'unknown'

export type Exposure = 'public' | 'internal'

/** 接口性质：决定是否命中「管理接口 / 调试接口暴露公网」规则 */
export type ApiKind = 'normal' | 'gm' | 'debug'

export type RiskLevel = 'high' | 'mid' | 'low'

export interface ApiParam {
  name: string
  type: string
  required: boolean
  /** body / query / path / header */
  location: string
}

/** 鉴权明细：管理后台详情抽屉展示 */
export interface AuthDetail {
  /** 携带方式，如 Header X-GM-Token */
  carrier: string
  /** 校验方式 */
  verify: string
  /** 值来源（静态 Token 的配置位置） */
  valueSource: string
  /** 识别依据：挂在哪个路由组的哪个中间件 */
  evidence: string
  /** 签名类鉴权是否带时间戳 / nonce */
  replayProtect: boolean
}

export interface ApiAsset {
  id: string
  /** 所属应用 */
  appName: string
  method: HttpMethod
  path: string
  params: ApiParam[]
  /** 系统推断的作用（CP 未确认时展示） */
  aiPurpose: string
  auths: AuthType[]
  authDetail: AuthDetail | null
  exposure: Exposure
  kind: ApiKind
  /** 鉴权关联的凭证 id（见 Credential） */
  credentialId: string | null
  /** 本次解析新增 */
  isNew: boolean
  /** 来源：部署解析 / CP 手动补充 */
  source: 'parsed' | 'manual'
}

export interface ScannedApp {
  name: string
  /** 应用类型，如 GM 平台 / 游戏服 / 配表平台 */
  kind: string
  /** 当前部署镜像（含版本） */
  image: string
  /** 是否存在公网入口（Ingress host） */
  isPublic: boolean
}

/** 镜像内扫描出的凭证 */
export interface Credential {
  id: string
  name: string
  appName: string
  /** 所在文件 */
  location: string
  /** 命中平台凭证指纹（如 center-key） */
  platformHit: boolean
  /** 关联说明 */
  linkedDesc: string
  reason: string
  suggestion: string
}

/** CP 对作用的确认记录 */
export interface PurposeRecord {
  text: string
  confirmed: boolean
  confirmedAt: string
}

export type ScanStatus = 'disabled' | 'scanning' | 'ready'

/** 单个 appId 的安全扫描状态（用户侧与管理后台共享） */
export interface ScanState {
  appId: string
  status: ScanStatus
  enabledAt: string
  lastParsedAt: string
  /** key = ApiAsset.id */
  purposes: Record<string, PurposeRecord>
  /** CP 手动补充的接口 */
  manualApis: ApiAsset[]
}

export type ScanStore = Record<string, ScanState>

export interface RiskHit {
  level: RiskLevel
  reason: string
}

export interface RiskResult {
  level: RiskLevel
  hits: RiskHit[]
}
