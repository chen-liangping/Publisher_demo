/**
 * 安全扫描状态的前端 mock store。
 *
 * 用户侧控制台与管理后台（window.open('/admin') 打开的独立标签页）共享状态：
 * 写 localStorage + 监听 storage 事件，做到「CP 开启扫描 / 确认作用 → 管理后台立刻看到」。
 * 写法与 Admin/credential-ban/mock.ts 保持一致。
 */

import { useSyncExternalStore } from 'react'

import { initiallyConfirmed, parsedApis } from './mock'
import type { ApiAsset, PurposeRecord, ScanState, ScanStore } from './types'

const STORAGE_KEY = 'publisher-demo:security-scan:v1'
/** 模拟解析镜像耗时 */
const PARSE_DURATION_MS = 2600

const createState = (appId: string): ScanState => ({
  appId,
  status: 'disabled',
  enabledAt: '',
  lastParsedAt: '',
  purposes: {},
  manualApis: []
})

let store: ScanStore = {}
const listeners = new Set<() => void>()

const persist = (): void => {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store))
  } catch {
    // 原型环境忽略写入失败
  }
}

const emit = (): void => {
  listeners.forEach(listener => listener())
}

const subscribe = (listener: () => void): (() => void) => {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

const getSnapshot = (): ScanStore => store

const ensure = (appId: string): ScanState => store[appId] ?? createState(appId)

const now = (): string => new Date().toISOString().slice(0, 19).replace('T', ' ')

const commit = (appId: string, next: ScanState): void => {
  store = { ...store, [appId]: next }
  persist()
  emit()
}

/** 解析完成：首次解析时写入作用的初始确认状态 */
const finishParse = (appId: string): void => {
  const state = ensure(appId)
  if (state.status !== 'scanning') return
  const purposes: Record<string, PurposeRecord> = { ...state.purposes }
  parsedApis.forEach(api => {
    if (purposes[api.id]) return
    const confirmed = initiallyConfirmed.includes(api.id)
    purposes[api.id] = { text: api.aiPurpose, confirmed, confirmedAt: confirmed ? now() : '' }
  })
  commit(appId, { ...state, status: 'ready', lastParsedAt: now(), purposes })
}

/** 开启安全扫描：进入解析中，完成后展示应用 API */
export const enableScan = (appId: string): void => {
  const state = ensure(appId)
  if (state.status !== 'disabled') return
  commit(appId, { ...state, status: 'scanning', enabledAt: now() })
  setTimeout(() => finishParse(appId), PARSE_DURATION_MS)
}

/** 重新解析：已确认的作用保留，新增接口按推断值待确认 */
export const reparse = (appId: string): void => {
  const state = ensure(appId)
  if (state.status !== 'ready') return
  commit(appId, { ...state, status: 'scanning' })
  setTimeout(() => finishParse(appId), PARSE_DURATION_MS)
}

/** 关闭安全扫描：清空解析结果与确认记录（原型内用于回到引导页） */
export const disableScan = (appId: string): void => {
  commit(appId, createState(appId))
}

/** 修改作用：修改即视为 CP 已确认 */
export const updatePurpose = (appId: string, apiId: string, text: string): void => {
  const state = ensure(appId)
  commit(appId, {
    ...state,
    purposes: { ...state.purposes, [apiId]: { text, confirmed: true, confirmedAt: now() } }
  })
}

export const setConfirmed = (appId: string, apiId: string, confirmed: boolean, fallbackText: string): void => {
  const state = ensure(appId)
  const prev = state.purposes[apiId]
  commit(appId, {
    ...state,
    purposes: {
      ...state.purposes,
      [apiId]: { text: prev?.text ?? fallbackText, confirmed, confirmedAt: confirmed ? now() : '' }
    }
  })
}

export const confirmAll = (appId: string, apis: ApiAsset[]): void => {
  const state = ensure(appId)
  const purposes: Record<string, PurposeRecord> = { ...state.purposes }
  const stamp = now()
  apis.forEach(api => {
    const prev = purposes[api.id]
    if (prev?.confirmed) return
    purposes[api.id] = { text: prev?.text ?? api.aiPurpose, confirmed: true, confirmedAt: stamp }
  })
  commit(appId, { ...state, purposes })
}

/** CP 补充解析遗漏的接口：作用由 CP 填写，直接视为已确认 */
export const addManualApi = (appId: string, api: ApiAsset): void => {
  const state = ensure(appId)
  commit(appId, {
    ...state,
    manualApis: [...state.manualApis, api],
    purposes: { ...state.purposes, [api.id]: { text: api.aiPurpose, confirmed: true, confirmedAt: now() } }
  })
}

/** 只在客户端 useEffect 里调用，避免 SSR / CSR 首屏不一致 */
let hydrated = false
export const hydrateScanStore = (): void => {
  if (hydrated || typeof window === 'undefined') return
  hydrated = true
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (raw) {
      store = { ...store, ...(JSON.parse(raw) as ScanStore) }
      // 刷新时若停在「解析中」，补一个完成定时器
      Object.values(store).forEach(s => {
        if (s.status === 'scanning') setTimeout(() => finishParse(s.appId), PARSE_DURATION_MS)
      })
      emit()
    }
  } catch {
    // 忽略损坏的本地数据
  }
  window.addEventListener('storage', event => {
    if (event.key !== STORAGE_KEY || !event.newValue) return
    try {
      store = JSON.parse(event.newValue) as ScanStore
      emit()
    } catch {
      // 忽略损坏的本地数据
    }
  })
}

export const useScanState = (appId: string): ScanState => {
  const snapshot = useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
  return snapshot[appId] ?? createState(appId)
}

/** 当前 appId 的全部接口：解析结果 + CP 补充 */
export const allApis = (state: ScanState): ApiAsset[] => [...parsedApis, ...state.manualApis]
