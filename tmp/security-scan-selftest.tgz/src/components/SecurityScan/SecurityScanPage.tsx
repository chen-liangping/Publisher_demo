'use client'

/**
 * 用户侧 · 监控 → 安全扫描
 *
 * 产品流程：
 * 1. 未开启：展示功能说明 + 示例数据预览，引导 CP 开启
 * 2. 开启后：平台解析各应用镜像（mock 为几秒的解析中状态）
 * 3. 解析完成：按应用展示 API 清单，CP 只需要看「入参」和「作用」，并逐条确认作用；
 *    不符的直接修改；解析遗漏的接口可手动补充。
 * 风险等级、鉴权等信息只在管理后台展示，用户侧不展示。
 */

import React, { useEffect, useMemo, useState } from 'react'
import {
  Button,
  Card,
  Descriptions,
  Drawer,
  Empty,
  Form,
  Input,
  Modal,
  Progress,
  Select,
  Space,
  Steps,
  Table,
  Typography,
  message
} from 'antd'
import type { ColumnsType } from 'antd/es/table'
import {
  CheckOutlined,
  PlusOutlined,
  ReloadOutlined,
  SafetyCertificateOutlined,
  SearchOutlined,
  UndoOutlined
} from '@ant-design/icons'

import { demoPreviewApis, scannedApps } from './mock'
import {
  addManualApi,
  allApis,
  confirmAll,
  disableScan,
  enableScan,
  hydrateScanStore,
  reparse,
  setConfirmed,
  updatePurpose,
  useScanState
} from './store'
import type { ApiAsset, HttpMethod, PurposeRecord, ScannedApp } from './types'
import { ImageTag, MethodTag, NewTag, Pill, PublicTag, formatParams } from './ui'

const { Title, Text, Paragraph } = Typography

interface SecurityScanPageProps {
  appId: string
}

/** 表格行：API + 当前作用确认记录 */
interface ApiRow {
  api: ApiAsset
  purpose: PurposeRecord
}

interface ManualApiForm {
  appName: string
  method: HttpMethod
  path: string
  params: string
  purpose: string
}

const pageCardStyle: React.CSSProperties = {
  borderRadius: 12,
  boxShadow: '0 1px 2px rgba(15, 23, 42, 0.06)'
}

export default function SecurityScanPage({ appId }: SecurityScanPageProps): React.ReactElement {
  useEffect(() => {
    hydrateScanStore()
  }, [])

  const scan = useScanState(appId)
  const [keyword, setKeyword] = useState<string>('')
  const [detailId, setDetailId] = useState<string | null>(null)
  const [enableOpen, setEnableOpen] = useState<boolean>(false)
  const [addOpen, setAddOpen] = useState<boolean>(false)
  const [form] = Form.useForm<ManualApiForm>()

  const apis = useMemo(() => allApis(scan), [scan])
  const purposeOf = (api: ApiAsset): PurposeRecord =>
    scan.purposes[api.id] ?? { text: api.aiPurpose, confirmed: false, confirmedAt: '' }

  const total = apis.length
  const done = apis.filter(a => purposeOf(a).confirmed).length
  const detailApi = apis.find(a => a.id === detailId) ?? null

  // ---------- 表格列：用户侧只展示入参与作用 ----------
  const buildColumns = (editable: boolean): ColumnsType<ApiRow> => [
    {
      title: '方法',
      dataIndex: ['api', 'method'],
      width: 90,
      render: (_: unknown, row: ApiRow) => <MethodTag method={row.api.method} />
    },
    {
      title: '路径',
      width: 260,
      render: (_: unknown, row: ApiRow) => (
        <Space size={4} wrap>
          {editable ? (
            // 交互：点击路径（标题字段）打开接口详情
            <Typography.Link style={{ fontFamily: 'ui-monospace, Menlo, monospace' }} onClick={() => setDetailId(row.api.id)}>
              {row.api.path}
            </Typography.Link>
          ) : (
            <Text style={{ fontFamily: 'ui-monospace, Menlo, monospace' }}>{row.api.path}</Text>
          )}
          {row.api.isNew && <NewTag />}
          {row.api.source === 'manual' && (
            <Pill bg="rgba(0, 0, 0, 0.05)" color="rgba(0, 0, 0, 0.65)">
              手动补充
            </Pill>
          )}
        </Space>
      )
    },
    {
      title: '入参',
      width: 260,
      render: (_: unknown, row: ApiRow) => (
        <Text type="secondary" style={{ fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 12 }}>
          {formatParams(row.api.params.map(p => p.name))}
        </Text>
      )
    },
    {
      title: '作用',
      width: 340,
      render: (_: unknown, row: ApiRow) =>
        editable ? (
          <Space direction="vertical" size={0} style={{ width: '100%' }}>
            {/* 交互：直接修改作用，保存即视为已确认 */}
            <Text
              editable={{
                tooltip: '修改作用',
                onChange: (value: string) => {
                  const text = value.trim()
                  if (!text || text === row.purpose.text) return
                  updatePurpose(appId, row.api.id, text)
                  message.success('作用已更新并确认')
                }
              }}
            >
              {row.purpose.text}
            </Text>
            {!row.purpose.confirmed && (
              <Text type="warning" style={{ fontSize: 12 }}>
                系统推断，请核对
              </Text>
            )}
          </Space>
        ) : (
          <Text>{row.purpose.text}</Text>
        )
    },
    {
      title: '状态',
      width: 100,
      render: (_: unknown, row: ApiRow) =>
        row.purpose.confirmed ? (
          <Pill bg="rgba(82, 196, 26, 0.12)" color="#389e0d">
            已确认
          </Pill>
        ) : (
          <Pill bg="rgba(250, 173, 20, 0.16)" color="#d48806">
            待确认
          </Pill>
        )
    },
    ...(editable
      ? [
          {
            title: '操作',
            width: 110,
            fixed: 'right' as const,
            render: (_: unknown, row: ApiRow) =>
              row.purpose.confirmed ? (
                <Button
                  type="text"
                  icon={<UndoOutlined />}
                  style={{ minHeight: 32 }}
                  onClick={() => setConfirmed(appId, row.api.id, false, row.api.aiPurpose)}
                >
                  撤销
                </Button>
              ) : (
                <Button
                  type="text"
                  icon={<CheckOutlined />}
                  style={{ minHeight: 32, color: '#1677ff' }}
                  onClick={() => setConfirmed(appId, row.api.id, true, row.api.aiPurpose)}
                >
                  确认
                </Button>
              )
          }
        ]
      : [])
  ]

  const matchKeyword = (api: ApiAsset, text: string): boolean => {
    const k = keyword.trim().toLowerCase()
    if (!k) return true
    return (api.path + text + api.appName).toLowerCase().includes(k)
  }

  // ---------- 状态一：未开启，引导页 + 示例数据 ----------
  if (scan.status === 'disabled') {
    const demoRows: ApiRow[] = demoPreviewApis.map(api => ({
      api,
      purpose: { text: api.aiPurpose, confirmed: api.id !== 'api-pay-notify', confirmedAt: '' }
    }))
    return (
      <Space direction="vertical" size={16} style={{ width: '100%' }}>
        <Card style={pageCardStyle} styles={{ body: { padding: 32 } }}>
          <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 14,
                background: 'rgba(22, 119, 255, 0.10)',
                color: '#1677ff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 28,
                flexShrink: 0
              }}
            >
              <SafetyCertificateOutlined />
            </div>
            <div style={{ flex: '1 1 480px', minWidth: 0 }}>
              <Title level={4} style={{ marginTop: 0 }}>
                安全扫描
              </Title>
              <Paragraph type="secondary" style={{ maxWidth: 760 }}>
                开启后，平台会在每次应用部署时自动解析镜像，梳理出各应用对外提供的 API 及其入参，并推断每个接口的作用。
                你只需要核对「作用」是否准确，平台会据此做上线前的安全评估。
                解析只读取镜像内容，不会向你的服务发送任何请求。
              </Paragraph>
              <Steps
                size="small"
                style={{ maxWidth: 760, margin: '20px 0 24px' }}
                items={[
                  { title: '开启安全扫描', description: '一次开启，之后每次部署自动解析' },
                  { title: '查看 API 清单', description: '按应用列出接口、入参与作用' },
                  { title: '确认作用', description: '不准确的直接修改，上线前全部确认' }
                ]}
              />
              <Button type="primary" size="large" icon={<SafetyCertificateOutlined />} onClick={() => setEnableOpen(true)}>
                开启安全扫描
              </Button>
            </div>
          </div>
        </Card>

        <Card
          style={{ ...pageCardStyle, background: '#fafafa' }}
          title={
            <Space>
              <span>开启后将展示</span>
              <Pill bg="rgba(0, 0, 0, 0.06)" color="rgba(0, 0, 0, 0.65)">
                示例数据
              </Pill>
            </Space>
          }
        >
          {/* 示例数据只读，不可操作 */}
          <div style={{ opacity: 0.75, pointerEvents: 'none' }}>
            <Table<ApiRow>
              rowKey={row => row.api.id}
              size="middle"
              columns={buildColumns(false)}
              dataSource={demoRows}
              pagination={false}
              scroll={{ x: 1000 }}
            />
          </div>
        </Card>

        <Modal
          open={enableOpen}
          title="开启安全扫描"
          okText="开启"
          onCancel={() => setEnableOpen(false)}
          onOk={() => {
            // 真实效果：状态切到解析中，完成后展示 API 清单（管理后台同步可见）
            enableScan(appId)
            setEnableOpen(false)
          }}
        >
          <Paragraph>开启后平台将立即解析当前已部署的 {scannedApps.length} 个应用，之后每次部署自动更新。</Paragraph>
          <ul style={{ paddingLeft: 20, color: 'rgba(0, 0, 0, 0.65)' }}>
            <li>只读取镜像内容，不会请求你的服务，不影响线上运行</li>
            <li>解析结果平台安全团队可见，用于上线前安全评估</li>
          </ul>
        </Modal>
      </Space>
    )
  }

  // ---------- 状态二：解析中 ----------
  if (scan.status === 'scanning') {
    return (
      <Card style={pageCardStyle} styles={{ body: { padding: 48 } }}>
        <Space direction="vertical" align="center" style={{ width: '100%' }} size={16}>
          <SafetyCertificateOutlined style={{ fontSize: 40, color: '#1677ff' }} />
          <Title level={4} style={{ margin: 0 }}>
            正在解析应用镜像…
          </Title>
          <Text type="secondary">
            正在解析 {scannedApps.map(a => a.name).join('、')}，通常需要几分钟，可以先离开本页
          </Text>
          <Progress percent={66} status="active" style={{ width: 360 }} showInfo={false} />
        </Space>
      </Card>
    )
  }

  // ---------- 状态三：已开启，展示应用 API ----------
  const pending = total - done
  const renderApp = (app: ScannedApp): React.ReactElement | null => {
    const appApis = apis.filter(a => a.appName === app.name)
    const rows: ApiRow[] = appApis
      .map(api => ({ api, purpose: purposeOf(api) }))
      .filter(row => matchKeyword(row.api, row.purpose.text))
    if (keyword && rows.length === 0) return null
    const appPending = appApis.filter(a => !purposeOf(a).confirmed).length
    return (
      <Card
        key={app.name}
        style={pageCardStyle}
        title={
          <Space size={8} wrap>
            <span style={{ fontWeight: 600 }}>{app.name}</span>
            <Text type="secondary" style={{ fontWeight: 400, fontSize: 13 }}>
              {app.kind}
            </Text>
            <ImageTag image={app.image} />
            {app.isPublic && <PublicTag />}
          </Space>
        }
        extra={
          <Space size={16}>
            <Text type="secondary" style={{ fontSize: 13 }}>
              {appApis.length} 个接口 · 待确认 <Text strong type={appPending > 0 ? 'warning' : undefined}>{appPending}</Text>
            </Text>
            <Button
              type="text"
              icon={<PlusOutlined />}
              onClick={() => {
                form.setFieldsValue({ appName: app.name, method: 'GET', path: '', params: '', purpose: '' })
                setAddOpen(true)
              }}
            >
              补充接口
            </Button>
          </Space>
        }
        styles={{ body: { padding: 0 } }}
      >
        <Table<ApiRow>
          rowKey={row => row.api.id}
          size="middle"
          columns={buildColumns(true)}
          dataSource={rows}
          pagination={false}
          scroll={{ x: 1200 }}
        />
      </Card>
    )
  }

  const visibleApps = scannedApps.map(renderApp).filter((n): n is React.ReactElement => n !== null)

  return (
    <Space direction="vertical" size={16} style={{ width: '100%' }}>
      <Card style={pageCardStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
          <div>
            <Space size={8}>
              <Title level={4} style={{ margin: 0 }}>
                安全扫描
              </Title>
              <Pill bg="rgba(82, 196, 26, 0.12)" color="#389e0d">
                已开启
              </Pill>
            </Space>
            <Paragraph type="secondary" style={{ margin: '8px 0 0' }}>
              以下接口由部署时自动解析，「作用」为系统推断。请逐条核对，不准确的直接修改；上线前需要确认全部接口。
              <br />
              最近解析：{scan.lastParsedAt || '—'}
            </Paragraph>
          </div>
          <Space wrap>
            <Button icon={<ReloadOutlined />} onClick={() => reparse(appId)}>
              重新解析
            </Button>
            <Button
              type="primary"
              icon={<CheckOutlined />}
              disabled={pending === 0}
              onClick={() => {
                confirmAll(appId, apis)
                message.success(`已确认 ${pending} 个接口`)
              }}
            >
              全部确认
            </Button>
          </Space>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 16, flexWrap: 'wrap' }}>
          <Progress
            percent={total === 0 ? 0 : Math.round((done / total) * 100)}
            style={{ flex: '1 1 320px', margin: 0 }}
            format={() => `已确认 ${done} / ${total}`}
          />
          <Input
            allowClear
            prefix={<SearchOutlined />}
            placeholder="搜索应用 / 路径 / 作用"
            style={{ width: 260 }}
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
          />
        </div>
      </Card>

      {visibleApps.length > 0 ? (
        visibleApps
      ) : (
        <Card style={pageCardStyle}>
          <Empty description="没有匹配的接口" />
        </Card>
      )}

      <div style={{ textAlign: 'right' }}>
        <Button
          type="text"
          danger
          onClick={() =>
            Modal.confirm({
              title: '关闭安全扫描？',
              content: '关闭后将清空解析结果与作用确认记录，之后部署不再自动解析。',
              okText: '关闭',
              okButtonProps: { danger: true },
              onOk: () => disableScan(appId)
            })
          }
        >
          关闭安全扫描
        </Button>
      </div>

      {/* 接口详情：入参明细 + 作用 */}
      <Drawer
        open={detailApi !== null}
        width={520}
        title={detailApi ? <span style={{ fontFamily: 'ui-monospace, Menlo, monospace' }}>{detailApi.path}</span> : ''}
        onClose={() => setDetailId(null)}
      >
        {detailApi && (
          <Space direction="vertical" size={20} style={{ width: '100%' }}>
            <Descriptions column={1} size="small">
              <Descriptions.Item label="应用">{detailApi.appName}</Descriptions.Item>
              <Descriptions.Item label="方法">
                <MethodTag method={detailApi.method} />
              </Descriptions.Item>
              <Descriptions.Item label="作用">
                <Text
                  editable={{
                    tooltip: '修改作用',
                    onChange: (value: string) => {
                      const text = value.trim()
                      if (!text) return
                      updatePurpose(appId, detailApi.id, text)
                    }
                  }}
                >
                  {purposeOf(detailApi).text}
                </Text>
              </Descriptions.Item>
              <Descriptions.Item label="状态">
                {purposeOf(detailApi).confirmed ? `已确认 · ${purposeOf(detailApi).confirmedAt}` : '待确认（系统推断）'}
              </Descriptions.Item>
            </Descriptions>
            <div>
              <Text strong>入参</Text>
              <Table
                style={{ marginTop: 8 }}
                size="small"
                rowKey="name"
                pagination={false}
                dataSource={detailApi.params}
                locale={{ emptyText: '无入参' }}
                columns={[
                  { title: '字段', dataIndex: 'name', render: (v: string) => <Text code>{v}</Text> },
                  { title: '类型', dataIndex: 'type' },
                  { title: '必填', dataIndex: 'required', render: (v: boolean) => (v ? '是' : '否') },
                  { title: '位置', dataIndex: 'location' }
                ]}
              />
            </div>
            {!purposeOf(detailApi).confirmed && (
              <Button type="primary" icon={<CheckOutlined />} onClick={() => setConfirmed(appId, detailApi.id, true, detailApi.aiPurpose)}>
                确认作用
              </Button>
            )}
          </Space>
        )}
      </Drawer>

      {/* 补充解析遗漏的接口 */}
      <Modal
        open={addOpen}
        title="补充接口"
        okText="添加"
        onCancel={() => setAddOpen(false)}
        onOk={async () => {
          const values = await form.validateFields()
          const app = scannedApps.find(a => a.name === values.appName)
          const names = values.params
            .split(/[,，\s]+/)
            .map(s => s.trim())
            .filter(Boolean)
          // 真实效果：写入 store，用户侧与管理后台都能看到；鉴权未知，管理后台按「未识别」评估风险
          addManualApi(appId, {
            id: `manual-${Date.now()}`,
            appName: values.appName,
            method: values.method,
            path: values.path.trim(),
            params: names.map(name => ({ name, type: 'string', required: true, location: values.method === 'GET' ? 'query' : 'body' })),
            aiPurpose: values.purpose.trim(),
            auths: ['unknown'],
            authDetail: null,
            exposure: app?.isPublic ? 'public' : 'internal',
            kind: 'normal',
            credentialId: null,
            isNew: false,
            source: 'manual'
          })
          setAddOpen(false)
          message.success('接口已添加')
        }}
      >
        <Form<ManualApiForm> form={form} layout="vertical" initialValues={{ method: 'GET' }}>
          <Form.Item label="应用" name="appName" rules={[{ required: true }]}>
            <Select options={scannedApps.map(a => ({ label: a.name, value: a.name }))} />
          </Form.Item>
          <Form.Item label="方法" name="method" rules={[{ required: true }]}>
            <Select options={(['GET', 'POST', 'PUT', 'DELETE'] as HttpMethod[]).map(m => ({ label: m, value: m }))} />
          </Form.Item>
          <Form.Item label="路径" name="path" rules={[{ required: true, message: '请输入路径' }, { pattern: /^\//, message: '以 / 开头' }]}>
            <Input placeholder="/api/xxx" />
          </Form.Item>
          <Form.Item label="入参" name="params" extra="多个参数用逗号分隔">
            <Input placeholder="uid, item_id" />
          </Form.Item>
          <Form.Item label="作用" name="purpose" rules={[{ required: true, message: '请填写作用' }]}>
            <Input placeholder="这个接口是做什么的" />
          </Form.Item>
        </Form>
      </Modal>
    </Space>
  )
}
