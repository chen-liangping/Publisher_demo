'use client'

import React, { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Tabs, Card, Typography, Space, Button, Input, Table, Alert, Image, Drawer, Tag, Divider } from 'antd'
import type { TabsProps } from 'antd'
import type { ColumnsType } from 'antd/es/table'

const { Title, Text, Link } = Typography

interface ItemRow {
  key: string
  itemId: string
  name: string
  i18nKey: string
  detailI18nKey: string
  iconUrl?: string
  value: string
  typeId: string
  typeName: string
  isStoreSupported: boolean
  isAiSupported: boolean
  attributes: string
}

interface GiftRow {
  key: string
  display_id: string
  gift_name: string
  ai_supported: boolean
  description: string
  items: string
  price_jpy: number
  price_value_ratio: number
  purchase_limit_type: string
  purchase_limit_amount: number
  amount_to_diamond: number
  vip_points: number
  payload: string
}

export default function GiftDataPage(): React.ReactElement {
  const [search, setSearch] = useState('')
  const [giftSearch, setGiftSearch] = useState('')
  // 控制「API 配置」Drawer 的显示与关闭
  const [apiDrawerOpen, setApiDrawerOpen] = useState(false)
  // 跳转到「接口测试」页面的路由
  const router = useRouter()
  const [items] = useState<ItemRow[]>([
    {
      key: 'I06000043超级氮气1', itemId: 'I06000043', name: '超级氮气1', i18nKey: 'L_I06000010', detailI18nKey: 'L_I06000010',
      iconUrl: 'https://ctwbox.g123.jp/?link_id=d90eb97e96084c668b02e00e37d69261', value: '500', typeId: '004', typeName: '消耗道具',
      isStoreSupported: false, isAiSupported: false, attributes: 'storeDisplayPrice:300,...'
    },
    {
      key: 'I06000041喵喵测试数据99', itemId: 'I06000041', name: '喵喵测试数据99', i18nKey: 'I06000040', detailI18nKey: 'I06000040',
      iconUrl: 'https://ik.imagekit.io/g123/production-ctw-box/game-box/preview/c78f83d6c465d79bb8d13c62da6743cafe620fd44b222b5dfcad7e02.png', value: '600', typeId: '003', typeName: '外观道具',
      isStoreSupported: false, isAiSupported: false, attributes: 'storeDisplayPrice:44,...'
    }
  ])

  const filteredItems = items.filter(i => `${i.itemId}${i.name}${i.i18nKey}`.includes(search))

  const itemColumns: ColumnsType<ItemRow> = useMemo(() => ([
    { title: 'item ID', dataIndex: 'itemId', key: 'itemId', width: 120, fixed: 'left' },
    { title: 'name', dataIndex: 'name', key: 'name', width: 160 },
    { title: 'i18n_Key', dataIndex: 'i18nKey', key: 'i18nKey', width: 180 },
    { title: 'detail_i18n_Key', dataIndex: 'detailI18nKey', key: 'detailI18nKey', width: 180 },
    { title: 'iconUrl', dataIndex: 'iconUrl', key: 'iconUrl', width: 160, render: (url?: string) => url ? <Image src={url} width={48} height={48} alt="icon" /> : '-' },
    { title: 'value', dataIndex: 'value', key: 'value', width: 120 },
    { title: 'type_Id', dataIndex: 'typeId', key: 'typeId', width: 120 },
    { title: 'type_Name', dataIndex: 'typeName', key: 'typeName', width: 160 },
    { title: 'isStoreSupported', dataIndex: 'isStoreSupported', key: 'isStoreSupported', width: 140, render: (v: boolean) => String(v) },
    { title: 'isAiSupported', dataIndex: 'isAiSupported', key: 'isAiSupported', width: 120, render: (v: boolean) => String(v) },
    { title: 'attributes', dataIndex: 'attributes', key: 'attributes', width: 260 },
    { title: '操作', key: 'actions', width: 100, fixed: 'right', render: () => <Button type="link" onClick={() => window.alert('原型：删除')}>删除</Button> }
  ]), [])

  const [gifts] = useState<GiftRow[]>([
    { key: '100006喵喵礼包测试', display_id: '100006', gift_name: '喵喵礼包测试', ai_supported: true, description: '周末限时特惠', items: '高级引擎: 1\nLOCK碎片: 100', price_jpy: 890, price_value_ratio: 500, purchase_limit_type: '每周限购', purchase_limit_amount: 1, amount_to_diamond: 15000, vip_points: 15000, payload: '12' },
    { key: '1000051234', display_id: '100005', gift_name: '1234', ai_supported: true, description: '周末限时特惠', items: 'LOCK碎片: 100\n高级引擎: 1', price_jpy: 500, price_value_ratio: 500, purchase_limit_type: '每月限购', purchase_limit_amount: 2, amount_to_diamond: 15000, vip_points: 15000, payload: '21' }
  ])

  const filteredGifts = gifts.filter(g => `${g.display_id}${g.gift_name}`.includes(giftSearch))

  const giftColumns: ColumnsType<GiftRow> = [
    { title: 'display_id', dataIndex: 'display_id', key: 'display_id', width: 160, fixed: 'left' },
    { title: 'gift_name', dataIndex: 'gift_name', key: 'gift_name', width: 160 },
    { title: 'ai_supported', dataIndex: 'ai_supported', key: 'ai_supported', width: 160, render: (v: boolean) => String(v) },
    { title: 'description', dataIndex: 'description', key: 'description', width: 150 },
    { title: 'items', dataIndex: 'items', key: 'items', width: 290, render: (v: string) => <span style={{ whiteSpace: 'pre-wrap' }}>{v}</span> },
    { title: 'price_jpy', dataIndex: 'price_jpy', key: 'price_jpy', width: 150 },
    { title: 'price_value_ratio', dataIndex: 'price_value_ratio', key: 'price_value_ratio', width: 190 },
    { title: 'purchase_limit_type', dataIndex: 'purchase_limit_type', key: 'purchase_limit_type', width: 180 },
    { title: 'purchase_limit_amount', dataIndex: 'purchase_limit_amount', key: 'purchase_limit_amount', width: 200 },
    { title: 'amount_to_diamond', dataIndex: 'amount_to_diamond', key: 'amount_to_diamond', width: 180 },
    { title: 'vip_points', dataIndex: 'vip_points', key: 'vip_points', width: 140 },
    { title: 'payload', dataIndex: 'payload', key: 'payload', width: 140 },
    { title: '操作', key: 'actions', width: 100, fixed: 'right', render: () => <Space><Button type="link" onClick={() => window.alert('原型：加入event')}>加入event</Button></Space> }
  ]

  const ItemTab = (
    <Space direction="vertical" size={16} style={{ display: 'flex' }}>
      <Alert type="success" showIcon message={<span><Text>2025-07-14 09:58:27</Text> 已发布</span>} />
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <Input.Search allowClear placeholder="搜索itemID、name、i18nkey" style={{ width: 260 }} onSearch={setSearch} />
        <Space size={12}>
          <Text style={{ fontSize: 12 }}>上次拉取时间 <Text style={{ fontSize: 12 }}>2025-06-24 08:00:14</Text></Text>
          <Button type="link" onClick={() => window.alert('原型：重新拉取')}>重新拉取</Button>
          <Button>回 退</Button>
          <Button type="primary" disabled>发 布</Button>
        </Space>
      </div>
      <Table rowKey="key" columns={itemColumns} dataSource={filteredItems} scroll={{ x: 1910 }} pagination={{ pageSize: 5 }} />
    </Space>
  )

  const GiftTab = (
    <Space direction="vertical" size={16} style={{ display: 'flex' }}>
      <Card>
        <Alert type="success" showIcon message={<span><Text>2025-06-30 10:26:49</Text> 已发布</span>} style={{ marginBottom: 12 }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
          <Input.Search allowClear placeholder="搜索display_id、gift_name" style={{ width: 260 }} onSearch={setGiftSearch} />
          <Space size={12}>
            <Text style={{ fontSize: 12 }}>上次拉取时间 <Text style={{ fontSize: 12 }}>2025-08-25 08:00:03</Text></Text>
            <Button type="link" onClick={() => window.alert('原型：重新拉取')}>重新拉取</Button>
            <Button>回 退</Button>
            <Button type="primary">发 布</Button>
          </Space>
        </div>
        <Table rowKey="key" columns={giftColumns} dataSource={filteredGifts} scroll={{ x: 2200 }} pagination={{ pageSize: 5 }} />
      </Card>
    </Space>
  )

  const itemsTabs: TabsProps['items'] = [
    { key: 'item', label: '道具', children: ItemTab },
    { key: 'gift', label: '礼包', children: GiftTab }
  ]

  return (
    <div style={{ padding: 24 }}>
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, marginBottom: 16 }}>
        <div style={{ padding: '16px 24px' }}>
          <Title level={3} style={{ marginBottom: 4 }}>礼包道具</Title>
          <Space size={8} wrap>
            <Text type="secondary">礼包道具用于展示和管理CP上传的礼包、道具资源，每天会定时更新，拉取最新列表数据同步至游戏。</Text>
            <Link href="https://w.g123.jp/doc/56s85yyf5pww5o2u5pon5l2c566a5lul-bEVHpHXGZL" target="_blank" rel="noopener noreferrer"><u>查看操作文档</u></Link>
          </Space>
        </div>
      </div>
      <Tabs
        items={itemsTabs}
        tabBarExtraContent={{
          right: (
            // 点击「自动化配置」按钮，打开右侧 Drawer 展示 API 配置详情
            <Button type="default" onClick={() => setApiDrawerOpen(true)}>
              自动化配置
            </Button>
          )
        }}
      />
      <Drawer
        title="API 配置"
        open={apiDrawerOpen}
        width={1040}
        placement="right"
        onClose={() => setApiDrawerOpen(false)}
        destroyOnClose
      >
        <Space direction="vertical" size={20} style={{ width: '100%' }}>
          <Card size="small"  style={{ borderRadius: 16, boxShadow: '0 4px 18px rgba(15,23,42,0.06)' }}>
            <Space direction="vertical" size={8} style={{ width: '100%' }}>
              <Title level={5} style={{ margin: 0 }}>认证 Token</Title>
              <Text type="secondary">平台调用您注册的接口时，会在请求头中携带该固定的 Token（Authorization: Basic &lt;Base64(appId:secret)&gt;），请在服务端进行鉴权处理。</Text>
              <Card
                size="small"
                style={{
                  marginTop: 12,
                  borderRadius: 12,
                  background: '#0f172a',
                  color: '#e5e7eb',
                  border: 'none'
                }}
              >
                <Text style={{ color: 'black', fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace' }}>
                  ZZFtZXRLc3Q6al1kY2N************************0d3BZVG5kWUsyW8=
                </Text>
              </Card>
            </Space>
          </Card>

          <Card size="small"  style={{ borderRadius: 16, boxShadow: '0 4px 18px rgba(15,23,42,0.06)' }}>
            <Space direction="vertical" size={12} style={{ width: '100%' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Title level={5} style={{ margin: 0 }}>接入 API</Title>
                {/* 点击「测试」进入接口测试页，用于模拟 Postman 风格的 API 调用 */}
                <Button type="primary" onClick={() => router.push('/api-test')}>
                  测试
                </Button>
              </div>

              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                <Text type="secondary">拉取道具资源列表</Text>
                <Card size="small" style={{ borderRadius: 12, background: '#f9fafb' }}>
                  <Space direction="vertical" size={6} style={{ width: '100%' }}>
                    <Space size={8} wrap>
                      <Tag color="green" style={{ borderRadius: 999, border: 'none', padding: '2px 10px' }}>GET</Tag>
                      <Text
                        code
                        style={{
                          fontSize: 14,
                          lineHeight: '24px',
                          padding: '4px 12px'
                        }}
                      >
                        https://g123-jp-gametest-slb.stg.g123-cpp.com/open-platform/api/v1/webhook/items/mock?queryType=assets
                      </Text>
                    </Space>
                    <Space style={{ justifyContent: 'space-between', width: '100%' }}>
                      <Text type="secondary" style={{ fontSize: 12 }}>上次成功同步时间 暂无数据</Text>
                      <Space size={12}>
                        <Text type="danger" style={{ fontSize: 12 }}>同步失败：fetch game [gametest] items from api error: get game [gametest] items from api failed with status code: ...</Text>
                        <Button type="link">立即同步</Button>
                      </Space>
                    </Space>
                  </Space>
                </Card>
              </Space>

              <Divider style={{ margin: '12px 0' }} />

              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                <Text type="secondary">拉取礼包资源列表</Text>
                <Card size="small" style={{ borderRadius: 12, background: '#f9fafb' }}>
                  <Space direction="vertical" size={6} style={{ width: '100%' }}>
                    <Space size={8} wrap>
                      <Tag color="green" style={{ borderRadius: 999, border: 'none', padding: '2px 10px' }}>GET</Tag>
                      <Text
                        code
                        style={{
                          fontSize: 14,
                          lineHeight: '24px',
                          padding: '4px 12px'
                        }}
                      >
                        https://g123-jp-gametest-slb.stg.g123-cpp.com/open-platform/api/v1/webhook/gifts/mock
                      </Text>
                    </Space>
                    <Space style={{ justifyContent: 'space-between', width: '100%' }}>
                      <Text type="secondary" style={{ fontSize: 12 }}>上次成功同步时间 暂无数据</Text>
                      <Space size={12}>
                      <Text type="danger" style={{ fontSize: 12 }}>同步失败：fetch game [gametest] items from api error: get game [gametest] items from api failed with status code: ...</Text>
                      <Button type="link">立即同步</Button>
                      </Space>
                    </Space>
                  </Space>
                </Card>
              </Space>

              <Divider style={{ margin: '12px 0' }} />

              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                <Text type="secondary">Popup API</Text>
                <Card size="small" style={{ borderRadius: 12, background: '#f9fafb' }}>
                  <Space direction="vertical" size={6} style={{ width: '100%' }}>
                    <Space size={8} wrap>
                      <Tag color="orange" style={{ borderRadius: 999, border: 'none', padding: '2px 10px' }}>POST</Tag>
                      <Text
                        code
                        style={{
                          fontSize: 14,
                          lineHeight: '24px',
                          padding: '4px 12px'
                        }}
                      >
                        https://g123-jp-gametest-slb.stg.g123-cpp.com/open-platform/gift/popup
                      </Text>
                    </Space>
                    <Text type="secondary" style={{ fontSize: 12 }}>
                      请自行配置防火墙白名单 IP；NAT EIP：「35.73.155.101」、「35.74.114.96」、「35.74.128.150」
                    </Text>
                  </Space>
                </Card>
              </Space>
            </Space>
          </Card>
        </Space>
      </Drawer>
    </div>
  )
}


